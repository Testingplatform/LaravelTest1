<?php $__env->startSection('content'); ?>

<!--=================================
wrapper -->

<div class="content-wrapper">
    <div class="page-title">
        <div class="row">
            <div class="col-sm-6">
                <h4 class="mb-0"> Users Master</h4>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
                    <li class="breadcrumb-item"><a href="index.html" class="default-color">Home</a></li>
                    <li class="breadcrumb-item active">User Master</li>
                </ol>
            </div>
        </div>
    </div>
    <!-- widgets -->
    <div class="row">


        <div class="col-xl-12 mb-30">

            <div class="card card-statistics mb-30">
                <div class="card-body">
                    <h5 class="card-title">User form</h5>
                    <form method="POST" action="<?php echo e(route('user_register')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class=" form-row">
                            <input type="hidden" name="hid" id="hid">
                            <div class=" col-md-3 form-group">
                                <label for="name">User Name</label>
                                <input type="text" value="<?php echo e(old('name')); ?>" class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" aria-describedby="nameHelp" placeholder="Enter Name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-red" role="alert">
                                    <?php echo e($message); ?> 
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class=" col-md-3 form-group">
                                <label for="email">Email address</label>
                                <input type="email" value="<?php echo e(old('email')); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-red" role="alert">
                                    <?php echo e($message); ?> 
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-3 form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password"  placeholder="Password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-red" role="alert">
                                    <?php echo e($message); ?> 
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-3 form-group">
                                <label for="usertype">User Type</label>
                                <select class="custom-select mr-sm-2" id="usertype" name="usertype">
                                    <option value="">--Select User Type--</option>
                                    <option value="1">Super User</option>
                                    <option value="2">Admin User</option>
                                    <option value="3">General</option>
                                </select>
                                <?php $__errorArgs = ['usertype'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-red" role="alert">
                                    <?php echo e($message); ?> 
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">

        <div class="col-xl-12 mb-30">     
            <div class="card card-statistics h-100"> 
                <div class="card-body">
                    <div class="d-block d-md-flex justify-content-between">
                        <div class="d-block">
                            <h5 class="card-title pb-0 border-0">Users List</h5>
                        </div>

                    </div>
                    <div class="table-responsive mt-15">
                        <table class="table center-aligned-table mb-0">
                            <thead>
                                <tr class="text-dark">
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>User Type</th>                   
                                    <th>Status</th>                     
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                <tr>
                                    <td><?php echo e($row->name); ?></td>
                                    <td><?php echo e($row->email); ?></td>
                                    <td><?php if( $row->usertype==1): ?>
                                        Super User
                                        <?php elseif($row->usertype==2): ?>
                                        Admin User
                                        <?php elseif($row->usertype==3): ?>
                                        General User
                                        <?php endif; ?></td>
                                    <td>
                                        <?php if( $row->status==0): ?>
                                        Deactive
                                        <?php elseif($row->status==1): ?>
                                        Active 
                                        <?php endif; ?>

                                    </td>
                                    <td><span onclick="edit_users('<?php echo e($row->id); ?>')" class="btn btn-outline-success btn-sm">EDIT</span></td>
                                    <td><span onclick="delete_users('<?php echo e($row->id); ?>')"  class="btn btn-outline-danger btn-sm">Delete</span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                                <?php echo e(csrf_field()); ?>

                            </tbody>
                              
                        </table>
                        <?php echo e($users->links()); ?>

                    </div>
                </div>
            </div>   
        </div>
    </div>
    <!--=================================
     wrapper -->

    <script>
        function edit_users(id){
        var _token = $('input[name="_token"]').val();
        $.ajax({
        type: 'POST',
                url: '<?php echo e(route('user_edit')); ?>',
                data: {id: id, _token:_token},
                dataType: 'json',
                success: function (response) {

                $('input[name="hid"]').val(response.id);
                $('input[name="name"]').val(response.name);
                $('input[name="email"]').val(response.email);
                $('#usertype').val(response.usertype);
                }
        });
        }
        function delete_users(id){

        var r = confirm("Are you Sure want to delete User?");
        if (r == true) {
        window.location.href = "/user_delete/" + id;
        }
        }
    </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tems\resources\views/admin/users.blade.php ENDPATH**/ ?>