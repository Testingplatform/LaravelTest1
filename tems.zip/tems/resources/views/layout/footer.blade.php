<!--=================================
 footer -->

<footer class="bg-white p-4">
    <div class="row">
        <div class="col-md-6">
            <div class="text-center text-md-left">
                <p class="mb-0"> &copy; Copyright <span id="copyright"> <script>document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))</script></span>. <a href="#"> Webmin </a> All Rights Reserved. </p>
            </div>
        </div>
        <div class="col-md-6">
            <ul class="text-center text-md-right">
                <li class="list-inline-item"><a href="#">Terms & Conditions </a> </li>
                <li class="list-inline-item"><a href="#">API Use Policy </a> </li>
                <li class="list-inline-item"><a href="#">Privacy Policy </a> </li>
            </ul>
        </div>
    </div>
</footer>
</div><!-- main content wrapper end-->
</div>
</div>
</div>

<!--=================================
 footer -->



<!--=================================
 jquery -->

<!-- jquery -->
<script src="js/jquery-3.3.1.min.js"></script>

<!-- plugins-jquery -->
<script src="js/plugins-jquery.js"></script>

<!-- plugin_path -->
<script>var plugin_path = 'js/index.html';</script>

<!-- chart -->
<script src="js/chart-init.js"></script>

<!-- calendar -->
<script src="js/calendar.init.js"></script>

<!-- charts sparkline -->
<script src="js/sparkline.init.js"></script>

<!-- charts morris -->
<script src="js/morris.init.js"></script>

<!-- datepicker -->
<script src="js/datepicker.js"></script>

<!-- sweetalert2 -->
<script src="js/sweetalert2.js"></script>

<!-- toastr -->
<script src="js/toastr.js"></script>

<!-- validation -->
<script src="js/validation.js"></script>

<!-- lobilist -->
<script src="js/lobilist.js"></script>

<!-- custom -->
<script src="js/custom.js"></script>
<script>
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
</script>
    
</body>

<!-- Mirrored from themes.potenzaglobalsolutions.com/html/webmin-bootstrap-4-angular-5-admin-dashboard-template/html/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 02 Aug 2019 08:08:21 GMT -->
</html>
