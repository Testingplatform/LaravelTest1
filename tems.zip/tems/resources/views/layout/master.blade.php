@include('layout.header')
@include('layout.nav')

@yield('content')

@include('layout.footer')
