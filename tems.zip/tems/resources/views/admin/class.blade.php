@extends('layout.master')

@section('content')

<!--=================================
wrapper -->

<div class="content-wrapper">
    <div class="page-title">
        <div class="row">
            <div class="col-sm-6">
                <h4 class="mb-0"> Classes Master</h4>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right">
                    <li class="breadcrumb-item"><a href="/home" class="default-color">Home</a></li>
                    <li class="breadcrumb-item active">Classes Master</li>
                </ol>
            </div>
        </div>
    </div>
    <!-- widgets -->
    <div class="row">


        <div class="col-xl-12 mb-30">

            <div class="card card-statistics mb-30">
                <div class="card-body">
                    <h5 class="card-title">Class form</h5>
                    <form method="POST" action="{{ route('class_create') }}">
                        @csrf
                        <div class=" form-row">
                            <input type="hidden" name="hid" id="hid">
                            <div class=" col-md-3 form-group">
                                <label for="name">Class Name</label>
                                <input type="text" value="{{ old('name') }}" class="form-control  @error('name') is-invalid @enderror" id="name" name="name" aria-describedby="nameHelp" placeholder="Enter Section Name">
                                @error('name')
                                <span class="invalid-feedback text-red" role="alert">
                                    {{ $message }} 
                                </span>
                                @enderror
                            </div>
                            
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">

        <div class="col-xl-12 mb-30">     
            <div class="card card-statistics h-100"> 
                <div class="card-body">
                    <div class="d-block d-md-flex justify-content-between">
                        <div class="d-block">
                            <h5 class="card-title pb-0 border-0">Class List</h5>
                        </div>

                    </div>
                    <div class="table-responsive mt-15">
                        <table class="table center-aligned-table mb-0">
                            <thead>
                                <tr class="text-dark">
                                    <th>SI.No</th>
                                    <th>Class Name</th>                                                        
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($cls as $row)   
                                <tr>
                                    <td>{{ $no++ }}</td>
                                    <td> {{ $row->class_name }}</td>
                                     
                                    <td><span onclick="edit_class('{{$row->id }}')" class="btn btn-outline-success btn-sm">EDIT</span></td>
                                    <td><span onclick="delete_class('{{$row->id }}')"  class="btn btn-outline-danger btn-sm">Delete</span></td>
                                </tr>
                                @endforeach
                              
                                {{ csrf_field() }}
                            </tbody>
                              
                        </table>
                        {{$cls->links()}}
                    </div>
                </div>
            </div>   
        </div>
    </div>
    <!--=================================
     wrapper -->

    <script>
        function edit_class(id){
        var _token = $('input[name="_token"]').val();
        $.ajax({
        type: 'POST',
                url: '{{ route('class_edit') }}',
                data: {id: id, _token:_token},
                dataType: 'json',
                success: function (response) {

                $('input[name="hid"]').val(response.id);
                $('input[name="name"]').val(response.class_name);
                 
                }
        });
        }
        function delete_class(id){

        var r = confirm("Are you Sure want to delete Class?");
        if (r == true) {
        window.location.href = "/class_delete/" + id;
        }
        }
    </script>

    @endsection
