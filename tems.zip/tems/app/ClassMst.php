<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClassMst extends Model
{
        protected $table = "class_msts";
	protected $fillable = ['class_name','created_by'];
	public $timestamps=true;
}
