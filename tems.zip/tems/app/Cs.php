<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cs extends Model
{
    //
}
